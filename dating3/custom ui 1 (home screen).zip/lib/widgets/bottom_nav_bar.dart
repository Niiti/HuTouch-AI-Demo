import 'package:flutter/material.dart';
import '../constants/constants.dart';
import 'nav_bar_item.dart';

class BottomNavBar extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onItemTapped;

  BottomNavBar({required this.selectedIndex, required this.onItemTapped});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(32),
        boxShadow: [
          BoxShadow(
            color: Color.fromRGBO(117, 34, 119, 0.15),
            offset: Offset(8, 0),
            blurRadius: 40,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          NavBarItem(
            index: 0,
            iconPath: 'assets/home.png',
            isSelected: selectedIndex == 0,
            onTap: onItemTapped,
          ),
          NavBarItem(
            index: 1,
            iconPath: 'assets/compass_icon.png',
            isSelected: selectedIndex == 1,
            onTap: onItemTapped,
          ),
          NavBarItem(
            index: 2,
            iconPath: 'assets/add_icon.png',
            isSelected: selectedIndex == 2,
            onTap: onItemTapped,
          ),
          NavBarItem(
            index: 3,
            iconPath: 'assets/comment_transparent_icon.png',
            isSelected: selectedIndex == 3,
            onTap: onItemTapped,
          ),
          NavBarItem(
            index: 4,
            iconPath: 'assets/User_avatar.png',
            isSelected: selectedIndex == 4,
            isProfile: true,
            onTap: onItemTapped,
          ),
        ],
      ),
    );
  }
}