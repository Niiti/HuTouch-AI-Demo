import 'package:flutter/material.dart';

const Color kPrimaryColor = Color.fromRGBO(75, 22, 76, 1);
const Color kAccentColor = Color.fromRGBO(220, 136, 208, 1);
const Color kTextColor = Color.fromRGBO(34, 23, 42, 1);
const Color kBackgroundColor = Color(0xFFFFFFFF);
const Color kTabBackgroundColor = Color.fromRGBO(248, 245, 250, 1);

const double kDefaultPadding = 16.0;