import 'package:flutter/material.dart';
import '../constants/constants.dart';
import '../models/chat_message.dart';
import '../models/match_profile.dart';
import '../widgets/heart_icon_widget.dart';
import '../widgets/match_profile_widget.dart';
import '../widgets/message_item_widget.dart';
import '../widgets/bottom_navigation.dart';

class MessagesOverviewScreen extends StatelessWidget {
  MessagesOverviewScreen({Key? key}) : super(key: key);

  final List<MatchProfile> recentMatches = [
    MatchProfile(imagePath: 'assets/Fabian.png'),
    MatchProfile(imagePath: 'assets/Halima.png'),
    MatchProfile(imagePath: 'assets/Selena.png'),
    MatchProfile(imagePath: 'assets/Vanessa.png'),
  ];

  final List<ChatMessage> messages = [
    ChatMessage(
      senderName: 'Alfredo Calzoni',
      messageSnippet: 'What about that new jacket if I ...',
      time: '09:18',
      imagePath: 'assets/Fabian.png',
      isUnread: true,
    ),
    ChatMessage(
      senderName: 'Clara Hazel',
      messageSnippet: 'I know right ?',
      time: '12:44',
      imagePath: 'assets/Halima.png',
      isUnread: true,
    ),
    ChatMessage(
      senderName: 'Brandon Aminoff',
      messageSnippet: 'I’ve already registered, can’t wai...',
      time: '08:06',
      imagePath: 'assets/brandon.png',
      isUnread: true,
    ),
    ChatMessage(
      senderName: 'Amina Mina',
      messageSnippet: 'It will have two lines of heading ...',
      time: '09:32',
      imagePath: 'assets/Selena.png',
      isUnread: false,
    ),
    ChatMessage(
      senderName: 'Savanna Hall',
      messageSnippet: 'It will have two lines of heading ...',
      time: '06:21',
      imagePath: 'assets/Vanessa.png',
      isUnread: false,
    ),
    ChatMessage(
      senderName: 'Sara Grif',
      messageSnippet: 'Oh come on!! Is it really that gre...',
      time: '05:01',
      imagePath: 'assets/boots.png',
      isUnread: false,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kOverlayColor,
      body: Stack(
        children: [
          // Background Image
            Positioned.fill(
            child: Image.asset(
              'assets/backgroundvector.png',
              fit: BoxFit.contain,
              width: double.infinity,
              height:10,
            ),
            ),
          Padding(
            padding: const EdgeInsets.only(top: 35),
            child: Column(
              children: [
                // Header Section
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 16, 24, 0),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: GestureDetector(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(40),
                              border: Border.all(
                                color: AppColors.whiteColor.withOpacity(0.08),
                                width: 1,
                              ),
                            ),
                            child: const Center(
                              child: Icon(
                                Icons.arrow_back,
                                color: AppColors.whiteColor,
                                size: 24,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Text(
                        'Messages',
                        style: AppTextStyles.headerTextStyle,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 32),
                // Recent Matches Section
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Recent Matches',
                        style: AppTextStyles.subHeaderTextStyle,
                      ),
                      const SizedBox(height: 16),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            const HeartIconWidget(),
                            const SizedBox(width: 20),
                            Row(
                              children: recentMatches.map((profile) {
                                return GestureDetector(
                                  onTap: () {
                                    // Implement functionality if needed
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.only(right: 20),
                                    child: MatchProfileWidget(profile: profile),
                                  ),
                                );
                              }).toList(),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Messages List
                Expanded(
                  child: Container(
                    decoration: const BoxDecoration(
                      color: AppColors.whiteColor,
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(32),
                      ),
                    ),
                    child: ListView.separated(
                      padding: const EdgeInsets.only(top: 16), // Adjusted padding
                      itemCount: messages.length,
                      separatorBuilder: (context, index) {
                        return Divider(
                          color: AppColors.blackColor.withOpacity(0.08),
                          height: 1,
                          indent: 24,
                          endIndent: 24,
                        );
                      },
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            // Navigate to conversation screen
                          },
                          child: MessageItemWidget(message: messages[index]),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Bottom Navigation Bar
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                BottomNavigation(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}