import 'package:flutter/material.dart';

class MatchesOverviewScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Implement the Matches Overview Screen UI
    return Scaffold(
      appBar: AppBar(
        title: Text('Matches Overview'),
      ),
      body: Center(
        child: Text('Matches Overview Screen'),
      ),
    );
  }
}
