class MatchProfile {
  final String imagePath;

  MatchProfile({required this.imagePath});
}