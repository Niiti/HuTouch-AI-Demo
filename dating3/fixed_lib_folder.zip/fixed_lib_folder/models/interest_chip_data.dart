// lib/models/interest_chip_data.dart

class InterestChipData {
  final String label;
  bool isSelected;

  InterestChipData({required this.label, required this.isSelected});
}
