class ChatMessage {
  final String senderName;
  final String messageSnippet;
  final String time;
  final String imagePath;
  final bool isUnread;

  ChatMessage({
    required this.senderName,
    required this.messageSnippet,
    required this.time,
    required this.imagePath,
    required this.isUnread,
  });
}