class User {
  final String imagePath;
  final String name;

  User({required this.imagePath, required this.name});
}
