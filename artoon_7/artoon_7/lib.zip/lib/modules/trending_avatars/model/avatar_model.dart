
class Avatar {
  final String title;
  final String imageUrl;

  Avatar({required this.title, required this.imageUrl});
}