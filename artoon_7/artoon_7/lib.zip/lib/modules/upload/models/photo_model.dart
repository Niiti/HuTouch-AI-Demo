
class PhotoModel {
  final String filePath;

  PhotoModel({required this.filePath});
}