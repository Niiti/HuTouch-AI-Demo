
import 'package:flutter/material.dart';
import 'views/upload_screen.dart';

class UploadModule extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return UploadScreen();
  }
}