
class Language {
  final String name;
  final String flag;

  Language({required this.name, required this.flag});
}