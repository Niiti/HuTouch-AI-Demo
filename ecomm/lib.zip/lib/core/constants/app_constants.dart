class AppConstants {
  static const String baseUrl = 'https://api.example.com/';
  static const Map<String, String> headers = {
    'Content-Type': 'application/json',
  };
}