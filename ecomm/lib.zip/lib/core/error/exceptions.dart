class ServerException implements Exception {}

class CacheException implements Exception {}