import 'package:dio/dio.dart';
import '../constants/app_constants.dart';

class ApiClient {
  final Dio dio;

  ApiClient({required this.dio}) {
    dio.options.baseUrl = AppConstants.baseUrl;
    dio.options.headers = AppConstants.headers;
  }
}