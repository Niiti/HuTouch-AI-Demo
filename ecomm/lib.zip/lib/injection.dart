import 'package:get_it/get_it.dart';
import 'package:injectable/injectable.dart';

// Ensure this import is correct and the file exists
import 'injection.config.dart';

final GetIt getIt = GetIt.instance;

@InjectableInit()
Future<void> init() async {
  getIt.init();
}