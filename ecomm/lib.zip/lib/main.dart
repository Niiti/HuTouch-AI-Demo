import 'package:flutter/material.dart';
import 'injection.dart';
import 'features/stylish_app/presentation/pages/home_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await init();
  runApp(StylishApp());
}

class StylishApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Stylish',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'SansSerif',
      ),
      home: HomePage(),
    );
  }
}