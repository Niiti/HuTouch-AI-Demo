import 'package:equatable/equatable.dart';

class Product extends Equatable {
  final String id;
  final String name;
  final String imageUrl;
  final String price;
  final String oldPrice;
  final String rating;

  Product({
    required this.id,
    required this.name,
    required this.imageUrl,
    required this.price,
    required this.oldPrice,
    required this.rating,
  });

  @override
  List<Object?> get props => [id, name, imageUrl, price, oldPrice, rating];
}