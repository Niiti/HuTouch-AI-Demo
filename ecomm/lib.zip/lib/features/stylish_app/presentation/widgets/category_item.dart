import 'package:flutter/material.dart';
import '../../domain/entities/category.dart';

class CategoryItem extends StatelessWidget {
  final Category category;
  CategoryItem({required this.category});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 80,
      margin: EdgeInsets.only(right: 16),
      child: Column(
        children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: Colors.grey.shade200,
            child: Image.network(
              category.icon,
              height: 30,
              width: 30,
              color: Colors.black,
            ),
          ),
          SizedBox(height: 8),
          Text(
            category.name,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'SansSerif',
              fontSize: 12,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}