import 'package:injectable/injectable.dart';

@injectable
class ProductViewModel {
  // ...existing code...
}
