import 'dart:async';
import '../../domain/entities/product.dart';
import '../../domain/usecases/get_products.dart';
import '../../../../core/error/failure.dart';

class ProductViewModel {
  final GetProducts getProductsUseCase;
  final _productsController = StreamController<List<Product>>();
  final _loadingController = StreamController<bool>();
  final _errorController = StreamController<String>();

  Stream<List<Product>> get productsStream => _productsController.stream;
  Stream<bool> get loadingStream => _loadingController.stream;
  Stream<String> get errorStream => _errorController.stream;

  ProductViewModel({required this.getProductsUseCase});

  void loadProducts() async {
    _loadingController.add(true);
    final failureOrProducts = await getProductsUseCase();
    failureOrProducts.fold((failure) {
      _loadingController.add(false);
      _handleFailure(failure);
    }, (products) {
      _loadingController.add(false);
      _productsController.add(products);
    });
  }

  void _handleFailure(Failure failure) {
    _errorController.add('An error occurred');
  }

  void dispose() {
    _productsController.close();
    _loadingController.close();
    _errorController.close();
  }
}