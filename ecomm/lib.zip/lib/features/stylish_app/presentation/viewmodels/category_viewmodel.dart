import 'dart:async';
import '../../domain/entities/category.dart';
import '../../domain/usecases/get_categories.dart';
import '../../../../core/error/failure.dart';

class CategoryViewModel {
  final GetCategories getCategoriesUseCase;
  final _categoriesController = StreamController<List<Category>>();
  final _loadingController = StreamController<bool>();
  final _errorController = StreamController<String>();

  Stream<List<Category>> get categoriesStream => _categoriesController.stream;
  Stream<bool> get loadingStream => _loadingController.stream;
  Stream<String> get errorStream => _errorController.stream;

  CategoryViewModel({required this.getCategoriesUseCase});

  void loadCategories() async {
    _loadingController.add(true);
    final failureOrCategories = await getCategoriesUseCase();
    failureOrCategories.fold((failure) {
      _loadingController.add(false);
      _handleFailure(failure);
    }, (categories) {
      _loadingController.add(false);
      _categoriesController.add(categories);
    });
  }

  void _handleFailure(Failure failure) {
    _errorController.add('An error occurred');
  }

  void dispose() {
    _categoriesController.close();
    _loadingController.close();
    _errorController.close();
  }
}