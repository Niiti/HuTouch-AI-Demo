import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';

import '../viewmodels/product_viewmodel.dart';
import '../widgets/product_card.dart';
import '../viewmodels/category_viewmodel.dart';
import '../widgets/category_item.dart';
import '../../../../core/utils/responsive.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  final productViewModel = GetIt.I<ProductViewModel>();
  final categoryViewModel = GetIt.I<CategoryViewModel>();

  @override
  void initState() {
    super.initState();
    productViewModel.loadProducts();
    categoryViewModel.loadCategories();
  }

  @override
  void dispose() {
    productViewModel.dispose();
    categoryViewModel.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: Responsive.isMobile(context) ? _buildMobileLayout() : _buildTabletDesktopLayout(),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      title: Text('Stylish'),
      centerTitle: true,
      elevation: 0,
    );
  }

  Widget _buildMobileLayout() {
    return SingleChildScrollView(
      child: Column(
        children: [
          // Add other UI components
          StreamBuilder(
            stream: categoryViewModel.categoriesStream,
            builder: (context, AsyncSnapshot snapshot) {
              if (snapshot.hasData) {
                return _buildCategoryList(snapshot.data);
              } else if (snapshot.hasError) {
                return Text('Error');
              } else {
                return CircularProgressIndicator();
              }
            },
          ),
          StreamBuilder(
            stream: productViewModel.productsStream,
            builder: (context, AsyncSnapshot snapshot) {
              if (snapshot.hasData) {
                return _buildProductGrid(snapshot.data);
              } else if (snapshot.hasError) {
                return Text('Error');
              } else {
                return CircularProgressIndicator();
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTabletDesktopLayout() {
    return Row(
      children: [
        Expanded(
          flex: 1,
          child: StreamBuilder(
            stream: categoryViewModel.categoriesStream,
            builder: (context, AsyncSnapshot snapshot) {
              if (snapshot.hasData) {
                return _buildCategoryList(snapshot.data);
              } else if (snapshot.hasError) {
                return Text('Error');
              } else {
                return CircularProgressIndicator();
              }
            },
          ),
        ),
        Expanded(
          flex: 2,
          child: StreamBuilder(
            stream: productViewModel.productsStream,
            builder: (context, AsyncSnapshot snapshot) {
              if (snapshot.hasData) {
                return _buildProductGrid(snapshot.data);
              } else if (snapshot.hasError) {
                return Text('Error');
              } else {
                return CircularProgressIndicator();
              }
            },
          ),
        ),
      ],
    );
  }

  Widget _buildCategoryList(List categories) {
    return Container(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        itemBuilder: (context, index) {
          return CategoryItem(category: categories[index]);
        },
      ),
    );
  }

  Widget _buildProductGrid(List products) {
    return GridView.builder(
      physics: NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: products.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: Responsive.isMobile(context) ? 2 : 4,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        childAspectRatio: 0.65,
      ),
      itemBuilder: (context, index) {
        return ProductCard(product: products[index]);
      },
    );
  }

  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      currentIndex: 0,
      selectedItemColor: Colors.red,
      unselectedItemColor: Colors.grey,
      showUnselectedLabels: true,
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.favorite_border),
          label: 'Wishlist',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.search),
          label: 'Search',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.settings),
          label: 'Setting',
        ),
      ],
    );
  }
}