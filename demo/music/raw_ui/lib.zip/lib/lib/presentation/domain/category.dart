class Category {
  final String imageUrl;
  final String title;

  Category({required this.imageUrl, required this.title});
}