class Artist {
  final String imageUrl;
  final String name;

  Artist({required this.imageUrl, required this.name});
}