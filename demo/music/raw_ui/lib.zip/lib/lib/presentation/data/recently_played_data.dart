
final recentlyPlayedData = [
  {
    'imageUrl': 'assets/image4.png',
    'songTitle': 'Inside Out',
    'artistName': 'The Chainsmokers, Charlee',
  },
  {
    'imageUrl': 'assets/image5.png',
    'songTitle': 'Beach House',
    'artistName': 'The Chainsmokers - Sick',
  },
  {
    'imageUrl': 'assets/image6.png',
    'songTitle': 'Young',
    'artistName': 'The Chainsmokers',
  },
  {
    'imageUrl': 'assets/image7.png',
    'songTitle': 'Kills You Slowly',
    'artistName': 'The Chainsmokers - World',
  },
  {
    'imageUrl': 'assets/image8.png',
    'songTitle': 'Setting Fires',
    'artistName': 'The Chainsmokers, XYLO',
  },
  {
    'imageUrl': 'assets/image9.png',
    'songTitle': 'Somebody',
    'artistName': 'The Chainsmokers, Drew',
  },
];