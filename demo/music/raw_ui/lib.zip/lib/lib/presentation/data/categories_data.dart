import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/category.dart';

final categoriesDataProvider = Provider<List<Category>>((ref) => [
  Category(imageUrl: 'assets/images/category_tamil.jpg', title: 'TAMIL'),
  Category(imageUrl: 'assets/images/category_international.jpg', title: 'INTERNATIONAL'),
  Category(imageUrl: 'assets/images/category_pop.jpg', title: 'POP'),
  Category(imageUrl: 'assets/images/category_hiphop.jpg', title: 'HIP-HOP'),
  Category(imageUrl: 'assets/images/category_dance.jpg', title: 'DANCE'),
  Category(imageUrl: 'assets/images/category_country.jpg', title: 'COUNTRY'),
  Category(imageUrl: 'assets/images/category_indie.jpg', title: 'INDIE'),
  Category(imageUrl: 'assets/images/category_jazz.jpg', title: 'JAZZ'),
  Category(imageUrl: 'assets/images/category_punk.jpg', title: 'PUNK'),
  Category(imageUrl: 'assets/images/category_rnb.jpg', title: 'R&B'),
  Category(imageUrl: 'assets/images/category_disco.jpg', title: 'DISCO'),
  Category(imageUrl: 'assets/images/category_rock.jpg', title: 'ROCK'),
]);