import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/artist.dart';

final artistsDataProvider = Provider<List<Artist>>((ref) => [
  Artist(imageUrl: 'assets/images/childish_gambino.jpg', name: 'Childish Gambino'),
  Artist(imageUrl: 'assets/images/marvin_gaye.jpg', name: 'Marvin Gaye'),
  Artist(imageUrl: 'assets/images/kanye_west.jpg', name: 'Kanye West'),
  Artist(imageUrl: 'assets/images/justin_bieber.jpg', name: 'Justin Bieber'),
  Artist(imageUrl: 'assets/images/charlie_puth.jpg', name: 'Charlie Puth'),
  Artist(imageUrl: 'assets/images/imagine_dragons.jpg', name: 'Imagine Dragons'),
  Artist(imageUrl: 'assets/images/kygo.jpg', name: 'Kygo'),
  Artist(imageUrl: 'assets/images/taylor_swift.jpg', name: 'Taylor Swift'),
  Artist(imageUrl: 'assets/images/the_chainsmokers.jpg', name: 'The Chainsmokers'),
]);
